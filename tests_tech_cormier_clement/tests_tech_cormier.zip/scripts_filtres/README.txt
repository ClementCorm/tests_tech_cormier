Les scripts ont été réalisé en Python (v3.8.10)

Les fichiers utilisés en entrées sont 'sal.txt' et 'ent.txt' présent dans le dossier ../data/

Les fichiers résultants sont créés dans le dossier ../result/filtre/exoX/

Exemples d'appel : 

Exercice 1 : python3 script_ex1.py
Exercice 2 : python3 script_ex2.py SAL_GE2 14 9
Exercice 3 : python3 script_ex3.py SAL_GEN 14 M.$
Exercice 4 : python3 script_ex4.py ENT_GEN 5 .*PACIFICO.*

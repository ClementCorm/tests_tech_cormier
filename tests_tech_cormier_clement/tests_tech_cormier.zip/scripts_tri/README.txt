Les scripts ont été réalisé en Python (v3.8.10)

Les fichiers utilisés en entrée sont 'sal.txt' et 'ent.txt' présents dans le dossier ../data/

Les fichiers résultants sont créés dans le dossier ../result/tri/

Exemples d'appel : 

Exercice 1 : python3 script_ex1.py
Exercice 2 : python3 script_ex2.py SAL_GE2 14
Exercice 3 : python3 script_ex3.py ENT_GEN 5

